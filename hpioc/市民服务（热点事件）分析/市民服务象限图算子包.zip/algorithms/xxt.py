# -*- coding:utf-8 -*-
"""
Description:

@author: QianChao
@date: 2020-08-17
"""
import pandas as pd
import numpy as np
import math
from epointml.utils import DbPoolUtil
import os


def readtable(mppurl, username, password, tablename, rx, ywlx, glyd, myd):
    """
    :param mppurl:
    :param username:
    :param password:
    :param tablename:
    :param rx: 工单来源字段，用来筛选热线数据
    :param ywlx: 业务类型
    :param glyd: 管理要点
    :param myd: 满意度
    :return:
    """
    os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'
    db = DbPoolUtil(url=mppurl, username=username, password=password)
    sql = 'select * from ' + tablename + ' where ' + rx + " like '%%热线%%' and " \
          + glyd + " in ('噪音污染','装修噪音','违法建筑','疾控防疫','拆迁安置'," \
                   "'动迁政策','群租现象','垃圾清理','环境垃圾','纠纷协调','物业安保', " \
                   "'维修添置','无证设摊','拖欠工资','社区服务网点','入学政策','外地户口入学', " \
                   "'经营性停车场','经适房') and " + ywlx + ' is not null and ' \
          + myd + " in ('满意','基本满意','一般','不满意')"

    result = db.execute_query(sql)
    df = [list(x) for x in result]
    df = pd.DataFrame(df)
    return df


def count_glyd_c(mppurl, username, password, tablename, rx, ywlx, glyd, myd):
    """
    对投诉类（'投诉举报类','求助类','其他类'）工单，按管理要点进行统计
    :param mppurl:
    :param username:
    :param password:
    :param tablename:
    :param rx: 工单来源字段，用来筛选热线数据
    :param ywlx: 业务类型
    :param glyd: 管理要点
    :param myd: 满意度
    :return:
    """
    os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'
    db = DbPoolUtil(url=mppurl, username=username, password=password)
    sql = 'select *'  + ' from ' + tablename +\
          ' where ' + rx + " like '%%热线%%' and " + ywlx +\
          " in ('投诉举报类','求助类','其他类') and " +\
          myd + " in ('满意','基本满意','一般','不满意')"
    result = db.execute_query(sql)
    dfc = [list(x) for x in result]
    dfc = pd.DataFrame(dfc)

    df_col = colname(mppurl, username, password, tablename)
    lst = np.array(df_col).tolist()
    col = [i[0] for i in lst]
    dfc.columns = col

    dfc.sort_values('synctime', inplace=True)
    dfc.drop_duplicates(subset='taskid', keep='last', inplace=True)
    dfc = pd.DataFrame(dfc[glyd].value_counts())
    print(dfc)
    return dfc


def count_glyd_s(mppurl, username, password, tablename, rx, ywlx, glyd, myd):
    """
    对服务类（'咨询类','意见建议类'）工单，按管理要点进行统计
    :param mppurl:
    :param username:
    :param password:
    :param tablename:
    :param rx: 工单来源字段，用来筛选热线数据
    :param ywlx: 业务类型
    :param glyd: 管理要点
    :param myd: 满意度
    :return:
    """
    os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'
    db = DbPoolUtil(url=mppurl, username=username, password=password)
    sql = 'select *' + ' from ' + tablename +\
          ' where ' + rx + " like '%%热线%%' and " + ywlx +\
          " in ('咨询类','意见建议类') and " +\
          myd + " in ('满意','基本满意','一般','不满意')"

    result = db.execute_query(sql)
    dfs = [list(x) for x in result]
    dfs = pd.DataFrame(dfs)

    df_col = colname(mppurl, username, password, tablename)
    lst = np.array(df_col).tolist()
    col = [i[0] for i in lst]
    dfs.columns = col

    dfs.sort_values('synctime', inplace=True)
    dfs.drop_duplicates(subset='taskid', keep='last', inplace=True)
    dfs = pd.DataFrame(dfs[glyd].value_counts())
    print(dfs)
    return dfs


def colname(mppurl, username, password, tablename):
    """
    连接mpp读取表中的字段名，并返回dataframe
    :param mppurl:
    :param username:
    :param password:
    :param tablename:
    :return:
    """
    os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'
    db = DbPoolUtil(url=mppurl, username=username, password=password)

    slst = tablename.split(".")
    tschema = slst[0]
    tname = slst[1]
    sql = 'select column_name from information_schema.columns ' \
          "where table_schema='" + tschema + "' and " + \
          "table_name='" + tname + "' ORDER BY ordinal_position"

    result = db.execute_query(sql)
    df = [list(x) for x in result]
    df = pd.DataFrame(df)
    return df


def myd_value(df, df_col_name, myd):
    """
    将满意度进行数值化，满意=1，基本满意=0.8，一般=0.6，不满意=0
    :param df:
    :param df_col_name:
    :param myd:满意度
    :return:
    """
    lst = np.array(df_col_name).tolist()
    col = [i[0] for i in lst]
    df.columns = col

    df['myd_value'] = 0
    df1 = df[df[myd].isin(['满意'])].copy()
    df1['myd_value'] = 1
    df2 = df[df[myd].isin(['基本满意'])].copy()
    df2['myd_value'] = 0.8
    df3 = df[df[myd].isin(['一般'])].copy()
    df3['myd_value'] = 0.6
    df4 = df[df['userevaluate'].isin(['不满意'])]

    frame = [df1, df2, df3, df4]
    dfv = pd.concat(frame)
    return dfv


def classify_df(dfv, ywlx, glyd):
    """
    根据业务类型和管理要点将数据分为服务（service）和投诉（complaint）
    :param dfv: myd_value()的输出结果，带字段名
    :param ywlx: 业务类型
    :param glyd: 管理要点
    :return:
    """
    dfv['new_ywlx'] = '投诉'
    # print(dfv[ywlx])
    df_s_temp = dfv[dfv[ywlx].isin(['咨询类', '意见建议类'])].copy()
    # print(df_s_temp)
    df_s_temp['new_ywlx'] = '服务'

    # 服务类数据
    df_s_temp['new_glyd'] = df_s_temp[glyd]
    df_st1 = df_s_temp[df_s_temp[glyd].isin(['拆迁安置'])].copy()
    df_st1['new_glyd'] = '动迁政策'
    df_st2 = df_s_temp[df_s_temp[glyd].isin(['外地户口入学'])].copy()
    df_st2['new_glyd'] = '入学政策'
    df_st3 = df_s_temp[df_s_temp[glyd].isin(['物业安保'])].copy()
    df_st3['new_glyd'] = '物业管理'
    df_st4 = df_s_temp[df_s_temp[glyd].isin(['维修添置'])].copy()
    df_st4['new_glyd'] = '物业管理'
    df_st5 = df_s_temp[df_s_temp[glyd].isin(['环境垃圾'])].copy()
    df_st5['new_glyd'] = '垃圾清理'
    df_st6 = df_s_temp[df_s_temp[glyd].isin(['动迁政策'])].copy()
    df_st7 = df_s_temp[df_s_temp[glyd].isin(['入学政策'])].copy()
    df_st8 = df_s_temp[df_s_temp[glyd].isin(['疾控防疫'])].copy()
    df_st9 = df_s_temp[df_s_temp[glyd].isin(['社区服务网点'])].copy()
    df_st10 = df_s_temp[df_s_temp[glyd].isin(['违法建筑'])].copy()
    df_st11 = df_s_temp[df_s_temp[glyd].isin(['经营性停车场'])].copy()
    df_st12 = df_s_temp[df_s_temp[glyd].isin(['噪音污染'])].copy()
    df_st13 = df_s_temp[df_s_temp[glyd].isin(['经适房'])].copy()
    df_st14 = df_s_temp[df_s_temp[glyd].isin(['垃圾清理'])].copy()
    frame_s = [df_st1, df_st2, df_st3, df_st4, df_st5, df_st6,
               df_st7, df_st8, df_st9, df_st10, df_st11, df_st12,
               df_st13, df_st14]
    df_s = pd.concat(frame_s, ignore_index=True)

    # print(df_s)

    # 投诉类数据
    df_c_temp = dfv[~dfv[ywlx].isin(['咨询类', '意见建议类'])].copy()
    df_c_temp['new_glyd'] = df_c_temp[glyd]
    df_ct1 = df_c_temp[df_c_temp[glyd].isin(['装修噪音'])].copy()
    df_ct1['new_glyd'] = '噪音污染'
    df_ct2 = df_c_temp[df_c_temp[glyd].isin(['环境垃圾'])].copy()
    df_ct2['new_glyd'] = '垃圾清理'
    df_ct3 = df_c_temp[df_c_temp[glyd].isin(['动迁政策'])].copy()
    df_ct3['new_glyd'] = '旧改征收'
    df_ct4 = df_c_temp[df_c_temp[glyd].isin(['拆迁安置'])].copy()
    df_ct4['new_glyd'] = '旧改征收'
    df_ct5 = df_c_temp[df_c_temp[glyd].isin(['噪音污染'])].copy()
    df_ct6 = df_c_temp[df_c_temp[glyd].isin(['违法建筑'])].copy()
    df_ct7 = df_c_temp[df_c_temp[glyd].isin(['疾控防疫'])].copy()
    df_ct8 = df_c_temp[df_c_temp[glyd].isin(['群租现象'])].copy()
    df_ct9 = df_c_temp[df_c_temp[glyd].isin(['纠纷协调'])].copy()
    df_ct10 = df_c_temp[df_c_temp[glyd].isin(['物业安保'])].copy()
    df_ct11 = df_c_temp[df_c_temp[glyd].isin(['维修添置'])].copy()
    df_ct12 = df_c_temp[df_c_temp[glyd].isin(['无证设摊'])].copy()
    df_ct13 = df_c_temp[df_c_temp[glyd].isin(['拖欠工资'])].copy()
    df_ct14 = df_c_temp[df_c_temp[glyd].isin(['垃圾清理'])].copy()
    frame_c = [df_ct1, df_ct2, df_ct3, df_ct4, df_ct5, df_ct6,
               df_ct7, df_ct8, df_ct9, df_ct10, df_ct11, df_ct12,
               df_ct13, df_ct14]
    df_c = pd.concat(frame_c, ignore_index=True)

    return df_s, df_c


def statistics(df, new_glyd='new_glyd'):
    """
    根据管理要点，统计管理要点的数量和满意度
    :param df:
    :param new_glyd:对原始管理要点进行合并后的字段
    :return:
    """
    df_r = pd.DataFrame()

    for name, group in df.groupby(new_glyd):
        row, col = group.shape
        typename = group.iloc[0].at[new_glyd]
        myd_v = round(group['myd_value'].mean()*100)
        temp = {'datatype': typename, 'num': row, 'sat': myd_v}
        df_r = df_r.append(temp, ignore_index=True)

    # 统计中位数
    median_n = df_r['num'].median()
    median_s = df_r['sat'].median()
    df_r['median_n'] = median_n
    df_r['median_s'] = median_s
    order = ['datatype', 'num', 'sat', 'median_n', 'median_s']
    df_r = df_r[order]

    return df_r


def coordinate_maximum(dfs, dfc, dfr_s, dfr_c):
    """
    投诉、服务象限图的Y轴坐标最大值
    :param dfs: count_glyd_s结果
    :param dfc: count_glyd_c结果
    :param dfr_s: statistics()服务类
    :param dfr_c: statistics()投诉类
    :return:
    """
    count_s = dfs.iloc[:, -1].max()
    count_c = dfc.iloc[:, -1].max()
    s_num = dfr_s['num'].max()
    c_num = dfr_c['num'].max()
    num_s = max(count_s, s_num)
    num_c = max(count_c, c_num)

    return num_s, num_c


def color_code_c(df_c, num_c, ratio=0.3, r_sat=90):
    """
    投诉象限图X轴坐标从满意度75开始，即坐标原点为（75,0）
    由于X,Y轴的刻度不同，原点坐标也不为(0,0)，在计算斜率k时，
    需要做相应变化，以管理要点坐标与(75,0)求斜率判断是分在1、2象限还是3、4象限为例
    要采用以下公式 k=(y值*100/num_c-0)/(s*(x值-75))
    其中s=(num_c*100/num_c-0)/(100-75)即100/25=4
    :param df_c:statistics()投诉类
    :param num_c:coordinate_maximum()num_c
    :param ratio: 第一象限在Y轴上的起点为（75，（1-ratio）*num_c）
    :param r_sat: 第四象限在X轴上的起点为（r_sat,0）
    :return:
    """
    row, col = df_c.shape
    df_c['color_code'] = 0
    # 坐标轴向上取整，避免最大值顶格
    maximum = math.ceil(num_c/500)*500
    df_c['coordinate_maximum'] = maximum
    for i in range(row):
        if df_c.loc[i, 'sat'] <= 75:
            # 满意度小于75的一律处理成75
            df_c.loc[i, 'sat'] = 75
            if df_c.loc[i, 'num'] > (1-ratio)*num_c:
                df_c.loc[i, 'color_code'] = 1
            else:
                df_c.loc[i, 'color_code'] = 2
        else:
            # 求斜率k
            k = 100*df_c.loc[i, 'num']/(4*maximum*(df_c.loc[i, 'sat']-75))
            if k > 1:
                k1 = 100*(df_c.loc[i, 'num']-(1-ratio)*num_c)/(4*maximum*df_c.loc[i, 'sat'])
                if k1 > 1:
                    df_c.loc[i, 'color_code'] = 1
                else:
                    df_c.loc[i, 'color_code'] = 2
            else:
                k2 = 100*df_c.loc[i, 'num']/(4*maximum*(df_c.loc[i, 'sat']-r_sat))
                if k2 < 1:
                    if k2 < 0:
                        df_c.loc[i, 'color_code'] = 3
                    else:
                        df_c.loc[i, 'color_code'] = 4
                else:
                    df_c.loc[i, 'color_code'] = 3

    return df_c


def color_code_s(df_s, num_s, o_sat=90):
    """
    服务象限图X轴坐标从满意度o_sat开始，即坐标原点为（o_sat,0）
    四个象限为 (100-o_sat)后均分，即第一象限为<=o_sat + (100-o_sat)/4
    第二象限为 (o_sat + (100-o_sat)/4,o_sat + (100-o_sat)/2]
    第三象限为 (o_sat + (100-o_sat)/2,o_sat + (100-o_sat)3/4]
    第四象限为 (o_sat + (100-o_sat)3/4,100]
    :param df_s:statistics()服务类
    :param num_s:coordinate_maximum()num_s
    :param o_sat:X轴坐标从满意度o_sat开始
    :return:
    """
    row, col = df_s.shape
    df_s['color_code'] = 0
    # 坐标轴向上取整，避免最大值顶格
    df_s['coordinate_maximum'] = math.ceil(num_s / 500) * 500
    for i in range(row):
        if df_s.loc[i, 'sat'] <= o_sat:
            # 满意度小于o_sat的一律处理成o_sat
            df_s.loc[i, 'sat'] = o_sat
            df_s.loc[i, 'color_code'] = 1
        elif df_s.loc[i, 'sat'] <= o_sat + (100 - o_sat)/4:
            df_s.loc[i, 'color_code'] = 1
        elif df_s.loc[i, 'sat'] <= o_sat + (100 - o_sat)/2:
            df_s.loc[i, 'color_code'] = 2
        elif df_s.loc[i, 'sat'] <= o_sat + (100 - o_sat)*3/4:
            df_s.loc[i, 'color_code'] = 3
        else:
            df_s.loc[i, 'color_code'] = 4

    return df_s


def create_xxt(mppurl, username, password, tablename, df):
    """
    创建结果表，字段顺序为'datatype', 'num', 'sat',
    'median_n', 'median_s', 'color_code', 'coordinate_maximum'
    :param mppurl:
    :param username:
    :param password:
    :param tablename:
    :param df:
    :return:
    """
    os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'
    db = DbPoolUtil(url=mppurl, username=username, password=password)

    cname = df.columns
    narray = np.array(df)
    lst = narray.tolist()


    sqlc = 'create table if  not exists ' + tablename + '('
    sqlc = sqlc + cname[0] + ' varchar,'
    sqlc = sqlc + cname[1] + ' float,'
    sqlc = sqlc + cname[2] + ' float,'
    sqlc = sqlc + cname[3] + ' float,'
    sqlc = sqlc + cname[4] + ' float,'
    sqlc = sqlc + cname[5] + ' int,'
    sqlc = sqlc + cname[6] + ' int)'
    db.execute(sqlc)
    try:
        sqli = 'insert into ' + tablename + ' ('
        for j in range(len(cname) - 1):
            sqli = sqli + cname[j] + ','
        sqli = sqli + cname[-1] + ') '
        v = 'values ('
        for k in range(len(cname) - 1):
            v = v + '%s,'
        v = v + '%s)'
        sqli = sqli + v
        db.execute_many_iud(sqli, lst)
    except:
        
        print('插表失败')
    else:
        # 删表
        sql = 'truncate ' + tablename
        db.execute_iud(sql)
        sqli = 'insert into ' + tablename + ' ('
        for j in range(len(cname) - 1):
            sqli = sqli + cname[j] + ','
        sqli = sqli + cname[-1] + ') '
        v = 'values ('
        for k in range(len(cname) - 1):
            v = v + '%s,'
        v = v + '%s)'
        sqli = sqli + v
        db.execute_many_iud(sqli, lst)


if __name__ == '__main__':
    url = 'jdbc:postgresql://215.0.2.36:25308/epoint_ztk'
    username = 'epoint'
    password = 'Epoint@123'
    rtable = 'public.mv_taskinfo3'
    rx = 'infotypename'
    myd = 'userevaluate'
    glyd = 'atname'
    ywlx = 'servicetype'
    ctable_c = 'public.smfw_mydxxt_ts_test'
    c_r_sat = 90
    c_ratio = 0.3
    ctable_s = 'public.smfw_mydxxt_fw_test'
    s_o_sat = 90

    df = readtable(url, username, password, rtable, rx, ywlx, glyd, myd)
    df1 = colname(url, username, password, rtable)
    print("成功读取数据")

    dfr = myd_value(df, df1, myd)
    dfr.drop_duplicates(subset='taskid',keep='last',inplace=True)

    df_s, df_c = classify_df(dfr, ywlx, glyd)
    dfr_s = statistics(df_s)
    dfr_c = statistics(df_c)
    print("成功统计满意度和工单量")

    dfc = count_glyd_c(url, username, password, rtable, rx, ywlx, glyd, myd)
    dfs = count_glyd_s(url, username, password, rtable, rx, ywlx, glyd, myd)


    num_s, num_c = coordinate_maximum(dfs, dfc, dfr_s, dfr_c)
    print("成功计算坐标最大值")

    dfr_c1 = color_code_c(dfr_c, num_c, c_ratio, c_r_sat)
    dfr_s1 = color_code_s(dfr_s, num_s, s_o_sat)
    print("成功计算象限颜色")

    print("dfr_s1",dfr_s1)
    print("dfr_c1", dfr_c1)


    create_xxt(url, username, password, ctable_s, dfr_s1)
    print("成功回写mpp库的" + ctable_s + "表")
    create_xxt(url, username, password, ctable_c, dfr_c1)
    print("成功回写mpp库的" + ctable_c + "表")