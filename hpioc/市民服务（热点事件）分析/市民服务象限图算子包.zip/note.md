# 满意度象限图
该算子代码功能包含：基于满意度和工单量，对特定管理要点类型的工单满意度进行象限图展示
## 目录文件说明
- algorithms 
    算法目录，目前收录满意度象限图算法.
- config
    配置文件目录
 - requirement
	需要的python三方包
- modelRun.py
    算子执行主程序。
    

# 满意度象限图算子执行步骤

1. MPP库准备表
将需要分析的数据导入MPP库中存成表

2. 在AI平台部署算子包

### AI平台中部署流程
#### 1. 进入AI平台
&emsp;&emsp;登录AI平台地址，输入用户名和密码，点击登录。

#### 2. 进入菜单人工智能->后台管理->程序包管理,上传zip包  

#### 3. 进入菜单人工智能->智能建模->模型管理，选择建模方式，新建“普通建模”
&emsp;&emsp;在对话框中输入模型名字，比如“满意度象限图”，选定运行节点，选好后点击确认添加。至此，我们完成了对"满意度象限图"模型的建立。但是还不能运行，因为还没有配置模型步骤。

#### 4. 配置init和satisfaction两个步骤，在satisfaction中可配置参数：
&emsp;&emsp; 点击智能建模->模型管理，找到"满意度象限图"，选择编辑模型(铅笔符号)，在“模型步骤信息”中，点击"新增模型步骤"。在弹出来的对话框中，填写"模型步骤名称",比如"初始化"，选择步骤2中上传的程序包，以及选定其对应的版本号。点击“步骤”下拉框，选择"init"。点击“确认添加”。至此，我们完成了对“满意度象限图”模型的“初始化”步骤的添加。

&emsp;&emsp; 接下来，我们继续添加“满意度象限图计算”步骤。同上述一样的方式，点击"新增模型步骤"，选择对应的程序包。在"步骤"下拉框中，选择"gini\_coe"，另外，我们需要在"上一步骤选择"中，选择已经配置好的“初始化”步骤。

&emsp;&emsp; 最后，我们需要配置"gini\_coe"的参数。总共有5个参数：<br>
&emsp;&emsp; 1."rturl" —— 读取原始输入数据的mpp连接信息，格式为jdbc:postgresql://ip/dbname<br>
&emsp;&emsp; 2."rtusername" —— 读取原始输入数据的mpp连接信息，用户名<br>
&emsp;&emsp; 3."rtpassword" —— 读取原始输入数据的mpp连接信息，密码<br>
&emsp;&emsp; 4."rtable" —— 读取数据表名，格式为模式名.表名<br>
&emsp;&emsp; 5."rx" —— 读取数据中，筛选热线数据的字段名<br>
&emsp;&emsp; 6."ywlx" —— 读取数据中，筛选业务类型的字段名<br>
&emsp;&emsp; 7."glyd" —— 读取数据中，筛选管理要点的字段名<br>
&emsp;&emsp; 8."myd" —— 读取数据中，满意度字段的字段名<br>
&emsp;&emsp; 9."cturl" —— 算子结果保存mpp库的连接信息，格式为jdbc:postgresql://ip/dbname<br>
&emsp;&emsp; 10."ctusername" —— 算子结果保存mpp库的连接信息，用户名<br>
&emsp;&emsp; 11."ctpassword" —— 算子结果保存mpp库的连接信息，密码<br>
&emsp;&emsp; 12."ctable_s" —— '服务'类象限图结果回写表名,格式为模式名.表名<br>
&emsp;&emsp; 13."s_o_sat" —— '服务'类象限图X轴坐标从满意度s_o_sat开始，即坐标原点为（s_o_sat,0）<br>
&emsp;&emsp; 14."ctable_c" —— '投诉'类象限图结果回写表名,格式为模式名.表名<br>
&emsp;&emsp; 15."c_ratio" —— '投诉'类象限图第一象限在Y轴上的起点为（0.75，（1-c_ratio）*Y轴最大值）<br>
&emsp;&emsp; 16."c_r_sat" —— '投诉'类象限图第四象限在X轴上的起点为（c_r_sat,0）<br>

#### 5. 勾选新建的模型，点击立即执行。  
#### 6. 在模型执行记录中可以观察是否成功  

### rtable示例（表中字段顺序不可改变，第一列为时间、第二列为街道、第三列为案件量、后面是案件大类和小类）
![avatar](figure/rtable.png)

### ctable_s示例
![avatar](figure/ctable_s.png)

### ctable_c示例
![avatar](figure/ctable_c.png)
