# -*- coding:utf-8 -*-
"""
Description:

@author: QianChao
@date: 2019-11-04
"""
from epointml.utils import commonUtil, elog
import os
commonUtil.setRootPath(os.path.split(os.path.realpath(__file__))[0])


def init(args):
    """
    初使化
    """
    logger = elog()
    logger.info("开始初始化")
    commonUtil.installpackage(args["whlsource"])
    logger.info("三方包下载完毕")
    return "OK"


def satisfaction(args):
    import algorithms.xxt as xxt
    logger = elog()

    rturl = args['rturl']
    rtusername = args['rtusername']
    rtpassword = args['rtpassword']
    rtable = args['rtable']
    rx = args['rx']
    myd = args['myd']
    glyd = args['glyd']
    ywlx = args['ywlx']
    cturl = args['cturl']
    ctusername = args['ctusername']
    ctpassword = args['ctpassword']
    ctable_s = args['ctable_s']
    s_o_sat = float(args['s_o_sat'])
    ctable_c = args['ctable_c']
    c_r_sat = float(args['c_r_sat'])
    c_ratio = float(args['c_ratio'])

    df = xxt.readtable(rturl, rtusername, rtpassword, rtable, rx, ywlx, glyd, myd)
    df1 = xxt.colname(rturl, rtusername, rtpassword, rtable)
    logger.info("成功读取数据")

    dfr = xxt.myd_value(df, df1, myd)
    dfr.sort_values('synctime',inplace=True)
    dfr.drop_duplicates(subset='taskid',keep='last',inplace=True)
    dfs, dfc = xxt.classify_df(dfr, ywlx, glyd)
    dfr_s = xxt.statistics(dfs)
    dfr_c = xxt.statistics(dfc)
    logger.info("成功统计满意度和工单量")

    dfc = xxt.count_glyd_c(rturl, rtusername, rtpassword, rtable, rx, ywlx, glyd, myd)
    dfs = xxt.count_glyd_s(rturl, rtusername, rtpassword, rtable, rx, ywlx, glyd, myd)
    num_s, num_c = xxt.coordinate_maximum(dfs, dfc, dfr_s, dfr_c)
    logger.info("成功计算坐标最大值")

    dfr_c1 = xxt.color_code_c(dfr_c, num_c, c_ratio, c_r_sat)
    dfr_s1 = xxt.color_code_s(dfr_s, num_s, s_o_sat)
    logger.info("成功计算象限颜色")

    xxt.create_xxt(cturl, ctusername, ctpassword, ctable_s, dfr_s1)
    logger.info("成功回写mpp库的" + ctable_s + "表")
    xxt.create_xxt(cturl, ctusername, ctpassword, ctable_c, dfr_c1)
    logger.info("成功回写mpp库的" + ctable_c + "表")

    return "OK"


def main():
    # 初始化
    init(commonUtil.load_step_param("init"))

    # 计算企业风险评分
    satisfaction(commonUtil.load_step_param("satisfaction"))


if __name__ == '__main__':
    main()
