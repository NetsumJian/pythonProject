# encoding: utf-8
# module pandas._libs.properties
# from D:\program\Anaconda3\lib\site-packages\pandas\_libs\properties.cp36-win_amd64.pyd
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def __pyx_unpickle_AxisProperty(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_CachedProperty(*args, **kwargs): # real signature unknown
    pass

# classes

class AxisProperty(object):
    def __delete__(self, *args, **kwargs): # real signature unknown
        """ Delete an attribute of instance. """
        pass

    def __get__(self, *args, **kwargs): # real signature unknown
        """ Return an attribute of instance, which is of type owner. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __set__(self, *args, **kwargs): # real signature unknown
        """ Set an attribute of instance to value. """
        pass

    axis = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class cache_readonly(object):
    def __delete__(self, *args, **kwargs): # real signature unknown
        """ Delete an attribute of instance. """
        pass

    def __get__(self, *args, **kwargs): # real signature unknown
        """ Return an attribute of instance, which is of type owner. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __set__(self, *args, **kwargs): # real signature unknown
        """ Set an attribute of instance to value. """
        pass

    func = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



CachedProperty = cache_readonly


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x00000275CA5CE978>'

__spec__ = None # (!) real value is "ModuleSpec(name='pandas._libs.properties', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x00000275CA5CE978>, origin='D:\\\\program\\\\Anaconda3\\\\lib\\\\site-packages\\\\pandas\\\\_libs\\\\properties.cp36-win_amd64.pyd')"

__test__ = {}

