import pandas as pd
import numpy as np
from datetime import timedelta
import datetime

def data_extract(df):

    df = df.drop_duplicates(subset=0, keep='first')
    df.drop([0, 6], axis=1, inplace=True)
    df.columns = ['STATUSNAME', 'PERCREATETIME', 'DISPATCHTIME', 'SOLVINGTIME', 'ENDTIME']
    df['PERCREATETIME'] = pd.to_datetime(df['PERCREATETIME'])
    df['DISPATCHTIME'] = pd.to_datetime(df['DISPATCHTIME'])
    df['SOLVINGTIME'] = pd.to_datetime(df['SOLVINGTIME'])
    df['ENDTIME'] = pd.to_datetime(df['ENDTIME'])

    df1 = df
    df2 = df1.sort_values(by='PERCREATETIME', ascending=False).reset_index()

    df_lct1 = df2[(df2['PERCREATETIME'] <= (
                datetime.datetime.now() - datetime.timedelta(days=29) + datetime.timedelta(days=14)).strftime(
        "%Y-%m-%d")) & (df2['PERCREATETIME'] >= (datetime.datetime.now() - datetime.timedelta(days=29)).strftime(
        "%Y-%m-%d"))]
    starttime = (datetime.datetime.now() - datetime.timedelta(days=29)).strftime("%Y-%m-%d")
    endtime = (datetime.datetime.now() - datetime.timedelta(days=29) + datetime.timedelta(days=14)).strftime("%Y-%m-%d")
    avetime = round(
        pd.to_timedelta([(((df_lct1['ENDTIME'] - df_lct1['PERCREATETIME']).sum()) / (df_lct1.count()[0]))]).astype(
            'timedelta64[h]')[0] / 24, 2)
    rate = round((((df_lct1[(df_lct1['SOLVINGTIME'] - df_lct1['DISPATCHTIME']) <= (
        timedelta(days=15, hours=0, minutes=0, seconds=0))]).count()[0]) / df_lct1.count()[0]), 2)

    list1 = [[starttime,endtime,avetime,rate]]
    df_final = pd.DataFrame(list1)
    df_final.columns = ['starttime', 'endtime', 'avetime', 'rate']
    df_final.fillna(0, inplace=True)
    df_final['rate'] = (str(int(df_final['rate'].iloc[0] * 100)) + '%')

    return  df_final