import pandas as pd
import numpy as np
from datetime import timedelta
import datetime

def data_extract(df):

    df = df.drop_duplicates(subset=0, keep='first')
    df.drop([0, 6], axis=1, inplace=True)
    df.columns = ['STATUSNAME', 'PERCREATETIME', 'DISPATCHTIME', 'SOLVINGTIME', 'ENDTIME']
    df['PERCREATETIME'] = pd.to_datetime(df['PERCREATETIME'])
    df['DISPATCHTIME'] = pd.to_datetime(df['DISPATCHTIME'])
    df['SOLVINGTIME'] = pd.to_datetime(df['SOLVINGTIME'])
    df['ENDTIME'] = pd.to_datetime(df['ENDTIME'])

    df1 = df
    df2 = df1.sort_values(by='PERCREATETIME', ascending=False).reset_index()

    df_lct2 = df2[(df2['PERCREATETIME'] <= datetime.datetime.now().strftime("%Y-%m-%d")) & (
                df2['PERCREATETIME'] >= (datetime.datetime.now() - datetime.timedelta(days=14)).strftime("%Y-%m-%d"))]
    starttime = (datetime.datetime.now() - datetime.timedelta(days=14)).strftime("%Y-%m-%d")
    endtime = datetime.datetime.now().strftime("%Y-%m-%d")
    slla = len(df_lct2[df_lct2['STATUSNAME'] == '待派遣']) + len(df_lct2[df_lct2['STATUSNAME'] == '待督办']) + len(
        df_lct2[df_lct2['STATUSNAME'] == '待结案']) + len(
        df_lct2[df_lct2['STATUSNAME'] == '已结案'])
    pq = len(df_lct2[df_lct2['STATUSNAME'] == '待督办']) + len(df_lct2[df_lct2['STATUSNAME'] == '待结案']) + len(
        df_lct2[df_lct2['STATUSNAME'] == '已结案'])
    cl = len(df_lct2[df_lct2['STATUSNAME'] == '待督办']) + len(df_lct2[df_lct2['STATUSNAME'] == '待结案']) + len(
        df_lct2[df_lct2['STATUSNAME'] == '已结案'])
    hf = len(df_lct2[df_lct2['STATUSNAME'] == '已结案'])
    ja = len(df_lct2[df_lct2['STATUSNAME'] == '已结案'])

    list1 = [[starttime,endtime,slla,pq,cl,hf,ja]]

    df_final = pd.DataFrame(list1)

    df_final.columns = ['starttime', 'endtime', 'slla', 'pq', 'cl', 'hf', 'ja']

    return df_final